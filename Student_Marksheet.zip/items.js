let items = [
    {StudentName:"Student 1", StudentID:"S1", Subject1:"100", Subject2:"98", Subject3:"76", Subject4:"82",Subject5:"92"},
    {StudentName:"Student 2", StudentID:"S2", Subject1:"92", Subject2:"100", Subject3:"98", Subject4:"76",Subject5:"82"},
    {StudentName:"Student 3", StudentID:"S3", Subject1:"76", Subject2:"92", Subject3:"100", Subject4:"98",Subject5:"76"},
    {StudentName:"Student 4", StudentID:"S4", Subject1:"82", Subject2:"76", Subject3:"92", Subject4:"100",Subject5:"98"}
]

module.exports = items;